DATA <- utils::read.csv(paste0("./data/", list.files("./data/")[1]), stringsAsFactors = FALSE, sep = ";")
