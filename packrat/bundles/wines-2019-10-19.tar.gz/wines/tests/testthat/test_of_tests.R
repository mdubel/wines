context("Test of tests")

test_that(
  "Test is tests works", {
    expect_equal(TRUE, TRUE)
  }
)
